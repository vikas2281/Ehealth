package com.ehealthcare;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Register")
public class Register extends HttpServlet {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		String name=req.getParameter("name");
		String gender=req.getParameter("gender");
		String email=req.getParameter("email");
		String mobile=req.getParameter("mobile");
		String password=req.getParameter("password");
		User user=new User();
		user.setName(name);
		user.setGender(gender);
		user.setEmail(email);
		user.setMobile(mobile);
		user.setPassword(password);
		int save=UserDao.addUser(user);
		if(save>0)
		{
			out.println("<h1>Register Succuessfully</h1>");
		}
		else
		{
			out.println("<h1>Error</h1>");
		}
	}

}
