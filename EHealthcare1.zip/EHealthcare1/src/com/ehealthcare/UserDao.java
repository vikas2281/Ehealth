package com.ehealthcare;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class UserDao 
{
	public static Connection getConnect()
	{
		Connection con=null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db1","root","Vikas@12345");
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
	}
	public static int addUser(User user)
	{
		int save=0;
		try 
		{
			Connection con=UserDao.getConnect();
			PreparedStatement ps=con.prepareStatement("INSERT INTO tb1(Name,Gender,Mobile,Email,Password) values(?,?,?,?,?)");
			ps.setString(1,user.getName());
			ps.setString(2,user.getGender());
			ps.setString(3,user.getMobile());
			ps.setString(4,user.getEmail());
			ps.setString(5,user.getPassword());
			save=ps.executeUpdate();
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		return save;
	}
	public static ArrayList<User> getAllUsers()
	{
		ArrayList<User> list=new ArrayList<User>();
		try 
		{
			Connection con=UserDao.getConnect();
			PreparedStatement ps=con.prepareStatement("SELECT * FROM User_Database.User_Table");
			ResultSet rs=ps.executeQuery();
			while (rs.next()) 
			{
				User user=new User();
				user.setName(rs.getString("name"));
				user.setGender(rs.getString("gender"));
				user.setMobile(rs.getString("mobile"));
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				list.add(user);
			}
		} 
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	public static String userValidate(User user)
	{
		//boolean status=false;
		String name="";
		try 
		{
			Connection con=UserDao.getConnect();
			PreparedStatement ps=con.prepareStatement("select Name from tb1 where email=? and password=?");
			ps.setString(1,user.getEmail());
			ps.setString(2,user.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				name=rs.getString(1);
			} 
		}
		catch (Exception e) 
		{
			// TODO: handle exception
			e.printStackTrace();
		}
		return name;
	}
}